package com.example.demo.model;

import com.example.demo.model.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Products {

	@Id
	private long SKU;
	private String Category;
	@ManyToOne
	private Brand Brand;
	private String Color;
	/**
	 * @return the sKU
	 */
	public long getSKU() {
		return SKU;
	}
	/**
	 * @param sKU the sKU to set
	 */
	public void setSKU(long sKU) {
		SKU = sKU;
	}
	/**
	 * @return the category
	 */
	public String getCategory() {
		return Category;
	}
	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		Category = category;
	}
	/**
	 * @return the brand
	 */
	public Brand getBrand() {
		return Brand;
	}
	/**
	 * @param brand the brand to set
	 */
	public void setBrand(Brand brand) {
		Brand = brand;
	}
	/**
	 * @return the color
	 */
	public String getColor() {
		return Color;
	}
	/**
	 * @param color the color to set
	 */
	public void setColor(String color) {
		Color = color;
	}
	public Products(long sKU, String category, Brand brand, String color) {
		super();
		SKU = sKU;
		Category = category;
		Brand = brand;
		Color = color;
	}
	
}
