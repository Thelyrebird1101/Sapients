package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.*;



@Repository
public interface ProductRepository extends JpaRepository<Products, Long>{

	@Query("SELECT new com.example.demo.model.BrandGroup(p.Brand, COUNT(p.Brand)"+"p.Brand, COUNT(p.Brand) FROM Products AS p GROUP BY p.Brand ORDER BY p.Brand DESC")
	List<BrandGroup> GroupByBrand();
	
}
