package com.example.demo.model;


import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.example.demo.model.*;

@Entity
public class Brand {
	@Id
	private long id;
	
	@OneToMany(mappedBy ="Brand")
	private List<Products> products;

}
