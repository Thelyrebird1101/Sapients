package com.example.demo.model;

public class BrandGroup {
	private String Brand;
	private Long total;
}
